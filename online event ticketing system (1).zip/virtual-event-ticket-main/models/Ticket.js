// models/Ticket.js
const mongoose = require('mongoose');

const ticketSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        trim: true,
        lowercase: true,
        match: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    },
    phone: {
        type: String,
        required: true,
        trim: true,
        match: /^\d{10}$/
    },
    branch: {
        type: String,
        required: true,
        trim: true
    },
    regNumber: {
        type: String,
        required: true,
        trim: true,
        unique: false // Keep unique: false if same regNumber can register for different events
    },
    eventId: {
        type: String,
        required: true,
        trim: true
    },
    eventName: {
        type: String,
        required: true,
        trim: true
    },
    ticketId: { // Unique ID for each generated ticket
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    qrCode: { // Stores the Data URL of the QR code image
        type: String,
        required: true
    },
    registrationDate: {
        type: Date,
        default: Date.now
    }
});

// Add a compound unique index if a user (regNumber) can only register once per event
ticketSchema.index({ regNumber: 1, eventId: 1 }, { unique: true });


const Ticket = mongoose.model('Ticket', ticketSchema);

module.exports = Ticket;