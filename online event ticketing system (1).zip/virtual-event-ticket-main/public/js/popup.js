// public/js/popup.js

function openPopup() {
  const popup = document.getElementById('popup');
  const innerPopup = document.getElementById('inner-popup'); // Select the inner div by its new ID

  if (popup && innerPopup) {
    popup.classList.remove('hidden');
    popup.classList.add('flex');
    setTimeout(() => {
      innerPopup.classList.add('scale-100', 'opacity-100');
    }, 50);
  } else {
    // This error will help diagnose if either the outer or inner popup element is missing
    console.error("Popup elements (outer or inner) not found! Outer:", popup, "Inner:", innerPopup);
  }
}

function closePopup() {
  const popup = document.getElementById('popup');
  const innerPopup = document.getElementById('inner-popup'); // Select the inner div by its new ID

  if (popup && innerPopup) {
    innerPopup.classList.remove('scale-100', 'opacity-100');
    setTimeout(() => {
      popup.classList.add('hidden');
      popup.classList.remove('flex');
    }, 300);
  } else {
    console.error("Popup elements (outer or inner) not found during close!");
  }
}

// Real-time Search on Homepage (This part is specific to index.ejs)
document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('searchInput');
  if (!searchInput) return; // Only run if searchInput exists

  searchInput.addEventListener('input', function () {
    const query = this.value.toLowerCase();
    document.querySelectorAll('.event-card').forEach(card => {
      const title = card.querySelector('h2').textContent.toLowerCase();
      const description = card.querySelector('p').textContent.toLowerCase(); // Search description too

      if (title.includes(query) || description.includes(query)) {
        card.style.display = 'block';
      } else {
        card.style.display = 'none';
      }
    });
  });
});