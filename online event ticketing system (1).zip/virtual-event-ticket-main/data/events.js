module.exports = [
  {
    id: 'vedic-vision',
    name: 'VEDIC VISION 2K26 – Mega Tech Mela',
    description: 'A 10-day Bootcamp on Java Full Stack followed by a 24-hour Hackathon.',
    date: 'APRIL 17 - 27, 2026',
    rawDate: '2026-04-17T09:00:00',
    registrationDeadline: '2026-04-17T23:59:59',
    time: '4:30 PM - 7:30 PM',
    fee: 'free',
    venue: 'Aditya university',
    eventType: 'Offline',
    theme: 'Sports & Health',
    organizer: {
      name: 'Dr. Hari Mohan',
      phone: '+91 9876543210'
    },
    image: '/images/aditya.png',
    benefits: [
      'Get hands-on experience with Java Full Stack development',
      'Build and deploy real-world web applications',
      'Compete in a 24-hour Hackathon on Sports & Health theme',
      'Work with mentors from the industry',
      'Earn a certificate of participation and achievement',
      'Opportunity to win ₹3,000 prize pool'
    ]
  },
  {
    id: 'ai-bootcamp',
    name: 'AI Bootcamp 2K26',
    description: 'An intensive workshop on building intelligent systems using Machine Learning and Python.',
    date: 'APRIL 12, 2026',
    rawDate: '2026-04-11T21:00:00',
    registrationDeadline: '2026-04-11T23:59:59',
    time: '10:00 AM - 4:00 PM',
    fee: 'free',
    venue: 'Online (Zoom)',
    eventType: 'Online',
    theme: 'Artificial Intelligence & Machine Learning',
    organizer: {
      name: 'Prof. Sneha Reddy',
      phone: '+91 9876000000'
    },
    image: '/images/ai-bootcamp.jpeg',
    benefits: [
      'Learn core Machine Learning algorithms',
      'Develop ML projects using Python and Scikit-Learn',
      'Get mentored by experienced AI professionals',
      'Hands-on model deployment experience',
      'Certificate of participation',
      'Recorded sessions and code repository access'
    ]
  },
  {
    id: 'code-challenge',
    name: 'Code Challenge 2K26',
    description: 'A 3-hour coding battle to solve algorithmic and data structure problems.',
    date: 'APRIL 13, 2026',
    rawDate: '2026-04-12T21:00:00',
    registrationDeadline: '2026-04-12T23:59:59',
    time: '6:00 PM - 9:00 PM',
    fee: 'Free',
    venue: 'Aditya university',
    eventType: 'Offline',
    theme: 'Competitive Coding',
    organizer: {
      name: 'Coding Club Team',
      phone: '+91 9876554321'
    },
    image: '/images/code-champ.jpeg',
    benefits: [
      'Improve problem-solving and competitive coding skills',
      'Top performers will receive medals and goodies',
      'Opportunity to get shortlisted for inter-college contests',
      'Interact with top student programmers',
      'Certificate of Merit and Participation'
    ]
  },
  {
   id: 'aditya-tech-fest',
   name: 'Aditya Tech Fest 2K26',
   description: 'A 2-day technical fest featuring coding contests, project expo, AI workshops, and startup pitching.',
   date: 'APRIL 15 - 16, 2026',
   rawDate: '2026-04-14T09:00:00',
   registrationDeadline: '2026-04-14T23:59:59',
   time: '9:00 AM - 5:00 PM',
   fee: '299',
   venue: 'Aditya University, Surampalem',
   eventType: 'Offline',
   theme: 'Technology & Innovation',
   organizer: {
     name: 'Aditya Technical Club',
     phone: '+91 9000000000'
   },
   image: '/images/aditya-techfest.png',
   benefits: [
     'Participate in Coding, AI & Web Development contests',
     'Project Expo and Startup Idea Pitching',
     'Win exciting cash prizes and goodies',
     'Networking with industry experts',
     'Participation & Winner Certificates'
   ]
 }
];
