const express = require('express');
const router = express.Router();
const QRCode = require('qrcode');
const { v4: uuidv4 } = require('uuid');
const Registration = require('../models/Registration');

// Event data
const events = [
  {
    id: "vedic-vision",
    name: "Vedic Vision 2K25 – Mega Tech Mela",
    shortDesc: "10‑day Java Bootcamp + 24‑hr Hackathon themed Sports & Health",
    longDesc: `📢 VEDIC VISION 2K25 is a fusion of tech & tradition! 
Join our 10‑day Bootcamp (Java Full Stack: Aug 4‑13, 4:30–7:30 PM) 
and then compete in a 24‑hour Hackathon (Aug 14) themed Sports & Health ⚽🧘‍♀🏋‍♂.
Team Size: 4‑6 | Prize Pool: ₹35,000 | Fee: ₹1199/head | Last Registration: July 31, 2025.
Benefits: Hands‑on Java stack experience, real team coding, networking, prizes & certificates.`,
    image: "/images/vedic.jpg",
    startDate: "2025-08-04T16:30:00",
  },
  {
    id: "ai-bootcamp",
    name: "AI Bootcamp 2K25",
    shortDesc: "5‑Day Hands‑On AI Workshop with projects & career guidance",
    longDesc: `Accelerate your AI career with our immersive 5‑day AI Bootcamp: 
live projects on ML, NLP, CV. 
Includes resume & portfolio guidance, expert mentors, certificate & job tips.`,
    image: "/images/ai_bootcamp.jpg",
    startDate: "2025-09-01T10:00:00",
  },
  {
    id: "coding-contest",
    name: "Code Marathon 2K25",
    shortDesc: "Competitive coding Contest—solve, rank & win!",
    longDesc: `Put your algorithm skills to the test in our Code Marathon: 
time‑bound challenges, online leaderboard, prizes & bragging rights.`,
    image: "/images/code_contest.jpg",
    startDate: "2025-08-20T10:00:00",
  }
];

router.get('/', async (req, res) => {
  // count registrations per event
  const counts = await Registration.aggregate([
    { $group: { _id: "$eventId", count: { $sum: 1 } } }
  ]);
  const map = counts.reduce((m, e) => ({ ...m, [e._id]: e.count }), {});
  res.render('index', { events, regCounts: map });
});

router.get('/event/:id', (req, res) => {
  const event = events.find(e => e.id === req.params.id);
  if (!event) return res.status(404).send("Event not found");
  res.render('event', { event });
});

router.post('/register', async (req, res) => {
  const { eventId, eventName, name, email, phone, branch, regNumber } = req.body;
  const exists = await Registration.findOne({ eventId, regNumber });
  if (exists) {
    return res.send(`<script>alert("You’ve already registered with Reg No ${regNumber} for this event.");window.history.back();</script>`);
  }
  const ticketID = uuidv4();
  const qrCodeURL = await QRCode.toDataURL(`Event:${eventName}\nRegNo:${regNumber}\nTicketID:${ticketID}`);
  await Registration.create({ eventId, eventName, name, email, phone, branch, regNumber, ticketID, qrCodeURL });
  res.render('ticket', { name, eventName, ticketID, qrCodeURL });
});

module.exports = router;
